const filterListData = [
  {
    _id: 1,
    name: 'All',
    active: true,
  },
  {
    _id: 2,
    name: 'RPG',
    active: false,
  },
  {
    _id: 3,
    name: 'MOBA',
    active: false,
  },
  {
    _id: 4,
    name: 'Battle',
    active: false,
  },
  {
    _id: 5,
    name: 'Racing',
    active: false,
  },
  {
    _id: 6,
    name: 'Fighting',
    active: false,
  },
];

export default filterListData;
