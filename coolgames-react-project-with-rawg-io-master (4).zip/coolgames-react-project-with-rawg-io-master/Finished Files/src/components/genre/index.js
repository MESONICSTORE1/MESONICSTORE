export { default as GenreList } from "./GenreList";
export { default as GenreItem } from "./GenreItem";