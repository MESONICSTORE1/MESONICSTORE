import React from 'react';

const CreatorList = () => {
    return (
        <CreatorListWrapper>
        </CreatorListWrapper>
    )
}

export default CreatorList;

const CreatorListWrapper = styled.div`
    margin-top: 140px;
`;