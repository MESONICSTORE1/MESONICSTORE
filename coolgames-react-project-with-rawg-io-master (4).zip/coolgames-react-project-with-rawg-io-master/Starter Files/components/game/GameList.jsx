import React from 'react';

const GameList = () => {
  return (
    <GameListWrapper>
    </GameListWrapper>
  )
}

export default GameList;

const GameListWrapper = styled.div`
  
`;
