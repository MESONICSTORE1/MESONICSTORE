export const gamesURL = `games`;
export const genresURL = `genres`;
export const storesURL = `stores`;
export const creatorsURL = `creators`;