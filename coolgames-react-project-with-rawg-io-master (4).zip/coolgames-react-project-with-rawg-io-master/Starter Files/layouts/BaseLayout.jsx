import React from 'react';

const BaseLayout = () => {
  return (
    <>
    </>
  )
}

export default BaseLayout
