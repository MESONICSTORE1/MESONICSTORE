import React from 'react'

const AppRouter = () => {
  return (
    <div>
      
    </div>
  )
}

export default AppRouter
